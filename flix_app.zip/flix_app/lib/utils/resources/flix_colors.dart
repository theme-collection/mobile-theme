import 'dart:ui';

const muvi_colorPrimary = Color(0xFFFE901C);
const muvi_colorPrimaryDark = Color(0xFFFE901C);
const muvi_colorAccent = Color(0xFFFE901C);
//const textColorPrimary = Color(0xFFFCFCFC);
const muvi_textColorPrimary = Color(0xFFD2D2D4);
const muvi_textColorSecondary = Color(0xFFA6A6A8);
const muvi_textColorThird = Color(0xFF77787A);
const muvi_white = Color(0xFFFFFFFF);
const muvi_appBackground = Color(0xFF26272B);
const muvi_navigationBackground = Color(0xFF202123);
const muvi_shadow_color = Color(0X95E9EBF0);
const search_edittext_color = Color(0xFF2C2D31);

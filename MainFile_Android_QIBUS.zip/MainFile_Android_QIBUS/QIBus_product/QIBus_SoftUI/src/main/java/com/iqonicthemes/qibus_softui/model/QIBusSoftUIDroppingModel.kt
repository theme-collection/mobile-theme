package com.iqonicthemes.qibus_softui.model

class QIBusSoftUIDroppingModel
/*constructor*/
(
        /*variable declaration*/

        /*getter*/

        val travelName: String, val loction: String, val duration: String)

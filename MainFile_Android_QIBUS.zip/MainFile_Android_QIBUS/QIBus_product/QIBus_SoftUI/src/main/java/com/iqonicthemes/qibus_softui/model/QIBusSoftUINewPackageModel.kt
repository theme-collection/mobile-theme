package com.iqonicthemes.qibus_softui.model

import java.io.Serializable

class QIBusSoftUINewPackageModel
/*constructor*/
(
        /*variable declaration*/

        /*getter*/

        val destination: String, val duration: String, val rating: String, val newprice: String, val booking: String, val image: Int) : Serializable

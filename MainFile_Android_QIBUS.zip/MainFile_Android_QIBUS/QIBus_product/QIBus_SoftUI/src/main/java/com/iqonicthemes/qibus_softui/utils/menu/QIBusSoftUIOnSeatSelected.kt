package com.iqonicthemes.qibus_softui.utils.menu

interface QIBusSoftUIOnSeatSelected {
    /*constructor*/
    fun onSeatSelected(count: Int, label: String)
}

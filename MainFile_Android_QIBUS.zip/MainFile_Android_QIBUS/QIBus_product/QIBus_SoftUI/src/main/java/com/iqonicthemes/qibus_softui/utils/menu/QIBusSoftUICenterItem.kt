package com.iqonicthemes.qibus_softui.utils.menu

class QIBusSoftUICenterItem/*constructor*/
(valueOf: String) : QIBusSoftUIAbstractItem(valueOf) {

    /*getter*/
    override val type: Int
        get() = QIBusSoftUIAbstractItem.TYPE_CENTER

}

package com.iqonicthemes.qibus_softui.model

class QIBusSoftUISeatModel
/*constructor*/
(
        /*variable declaration*/

        val softUISeatType: QIBusSoftUISeatType) {
    /*getter*/

    /*setter*/
    var isSelected = false
}

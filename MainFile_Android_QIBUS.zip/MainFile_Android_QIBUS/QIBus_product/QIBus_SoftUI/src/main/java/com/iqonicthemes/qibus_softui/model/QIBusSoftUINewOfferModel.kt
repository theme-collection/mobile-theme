package com.iqonicthemes.qibus_softui.model

import java.io.Serializable

class QIBusSoftUINewOfferModel
/*constructor*/
(
        /*variable declaration*/

        /*getter*/
        val usecode: String) : Serializable

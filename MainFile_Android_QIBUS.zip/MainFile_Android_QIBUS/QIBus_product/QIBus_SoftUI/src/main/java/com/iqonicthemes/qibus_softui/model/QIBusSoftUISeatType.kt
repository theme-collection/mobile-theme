package com.iqonicthemes.qibus_softui.model

enum class QIBusSoftUISeatType {
    EMPTY,
    BOOKED,
    LADIES
}

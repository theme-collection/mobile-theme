package app.iqonicthemes.qibus.utils.menu;

public interface OnSeatSelected {
    /*constructor*/
    void onSeatSelected(int count, String label);
}

package app.iqonicthemes.qibus.model;

public enum SeatType {
    EMPTY,
    BOOKED,
    LADIES
}

import 'package:flutter/material.dart';

const backgroundColor = Color(0xFFFFFFFF);
const GPAppColor = Color(0xFF2962ff);
const GPColorBlack = Color(0xFF010101);
const GPLightBlue = Color(0xFFE8F0FD);

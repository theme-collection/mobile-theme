package com.iqonic.tiktok

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

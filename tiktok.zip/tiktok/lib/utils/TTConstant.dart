const TTAppName = 'TikTak';
const baseUrl = 'https://iqonic.design/themeforest-images/Mimik';

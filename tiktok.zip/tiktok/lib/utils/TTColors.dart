import 'package:flutter/material.dart';

const TTColorSerpent = Color(0xFF69C9D0);
const TTColorRed = Color(0xFFEE1D52);
const TTColorBlack = Color(0xFF010101);

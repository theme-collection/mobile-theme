class EAInboxModel{
  String? image;
  String? name;
  String? msg;

  EAInboxModel({this.image, this.name, this.msg});
}
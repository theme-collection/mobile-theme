import 'package:event_flutter/screens/PurchaseMoreScreen.dart';
import 'package:flutter/material.dart';

class EATomorrowTicketScreen extends StatefulWidget {
  const EATomorrowTicketScreen({Key? key}) : super(key: key);

  @override
  _EATomorrowTicketScreenState createState() => _EATomorrowTicketScreenState();
}

class _EATomorrowTicketScreenState extends State<EATomorrowTicketScreen> {
  @override
  Widget build(BuildContext context) {
    return const PurchaseMoreScreen();
  }
}

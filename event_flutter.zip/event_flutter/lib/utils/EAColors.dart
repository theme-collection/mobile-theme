import 'package:flutter/cupertino.dart';

const primaryColor1=Color(0xFFED3269);
const primaryColor2=Color(0xFFFD5F3E);
const facebook=Color(0xFF3B5997);
const twitter=Color(0xFF1DA0F1);
import 'package:flutter/material.dart';

const colorBlue = Color(0xFF0091f2);
const colorBackGround = Color(0xFFfafafa);
const fbColor = Color(0xFF385085);
const commentViewBackGround = Color(0xFFf6f7f7);

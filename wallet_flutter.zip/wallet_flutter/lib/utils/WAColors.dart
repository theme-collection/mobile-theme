import 'package:flutter/material.dart';

const WAPrimaryColor = Color(0xFF6C56F9);
const WAAccentColor = Color(0xFF26C884);

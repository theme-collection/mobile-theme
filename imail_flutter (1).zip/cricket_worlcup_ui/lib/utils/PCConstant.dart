/*fonts*/
const fontRegular = 'Regular';
const fontMedium = 'Medium';
const fontSemiBold = 'Semibold';
const fontBold = 'Bold';
const BaseUrl = 'https://assets.iqonic.design/old-themeforest-images/prokit';

import 'package:flutter/material.dart';

const Cricket_white = Color(0xFFffffff);
const Cricket_Primary = Color(0xFF232883);
const Cricket_Gradient_color1 = Color(0xFFF92C5B);
const Cricket_Gradient_color2 = Color(0xFF2b33bf);
const Cricket_textColorPrimary = Color(0xFF333333);
const Cricket_textColorSecondary = Color(0xFF9D9D9D);
const Cricket_ShadowColor = Color(0X95E9EBF0);
const Cricket_color1 = Color(0xFF8f93d6);
const Cricket_SkyBlue_Color = Color(0xFF65f7ff);
const Cricket_app_Background = Color(0xFFf3f5f9);
const Cricket_BlackColor = Color(0xFF000000);

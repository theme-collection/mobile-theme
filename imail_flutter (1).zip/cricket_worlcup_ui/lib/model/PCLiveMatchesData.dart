class PCLiveMatchesModel {
  String title = "";
  String type = "";
  String place = "";
  String team1 = "";
  String team2 = "";
  String team1Score = "";
  String team2Score = "";
  String won = "";
  bool live = false;

  PCLiveMatchesModel(this.title, this.type, this.place, this.team1, this.team2, this.team1Score, this.team2Score, this.won, this.live);
}

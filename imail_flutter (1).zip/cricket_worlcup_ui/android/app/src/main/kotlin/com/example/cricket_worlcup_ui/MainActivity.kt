package com.example.cricket_worlcup_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

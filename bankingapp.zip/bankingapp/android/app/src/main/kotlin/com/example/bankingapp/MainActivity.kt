package com.example.bankingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

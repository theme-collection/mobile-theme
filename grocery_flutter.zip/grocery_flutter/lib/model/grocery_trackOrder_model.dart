class TrackOrder {
  var orderName;
  var orderAmount;
  var totelItem;

  TrackOrder({this.orderName, this.orderAmount, this.totelItem});
}

List<TrackOrder> trackOrder = [
  TrackOrder(
    orderName: 'Vegetables',
    orderAmount: '1820.00',
    totelItem: '04',
  ),
];

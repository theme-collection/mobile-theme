package com.iqonic.trallo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

class BoardDetailOptionModel {
  Widget? icon;
  String? name;
  Widget? content;
  Function? onTap;

  BoardDetailOptionModel({this.icon, this.name, this.onTap});
}

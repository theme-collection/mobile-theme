class CardMembersModel {
  String? profileImg;
  String? name;
  String? userName;
  bool isActive = false;

  CardMembersModel({this.profileImg, this.name, this.userName});
}

class CardModel {
  String? name;
  bool? isSelected;

  CardModel({this.name, this.isSelected});
}

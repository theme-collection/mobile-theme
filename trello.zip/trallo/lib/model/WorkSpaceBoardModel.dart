class WorkSpaceBoardModel {
  String? name;
  String? image;
  String? team;
  String? visibility;

  WorkSpaceBoardModel({this.name, this.image, this.team, this.visibility});
}

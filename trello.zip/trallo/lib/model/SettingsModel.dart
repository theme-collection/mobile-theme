import 'package:flutter/cupertino.dart';

class SettingsModel {
  String? name;
  String? subName;
  Widget? icon;

  SettingsModel({this.name, this.subName, this.icon});
}

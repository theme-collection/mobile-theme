class BoardModel {
  String? name;
  bool? isSelected;
  bool isToggle = false;

  BoardModel({this.name, this.isSelected});
}

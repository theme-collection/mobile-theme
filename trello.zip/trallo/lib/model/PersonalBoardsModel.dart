class PersonalBoardModel {
  String? name;
  String? image;
  String? team;
  String? visibility;
  bool? starred;

  PersonalBoardModel({this.name, this.image, this.team, this.visibility, this.starred});
}

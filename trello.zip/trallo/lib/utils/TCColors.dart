import 'package:flutter/material.dart';

const backgroundColor = Color(0xFF0079BE);
const appBarColor = Color(0xFF00407E);
const textColorPrimary = Color(0xFFFFFFFF);
const textColorSecondary = Color(0xB3FFFFFF);
const buttonColor = Color(0xFF61BD50);

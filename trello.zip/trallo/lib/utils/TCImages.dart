import 'package:trallo/utils/TCConstants.dart';

const tc_WalkThroughImg1 = '$baseUrl/trello/walkthrough1.png';
const tc_WalkThroughImg2 = '$baseUrl/trello/walkthrough2.png';
const tc_WalkThroughImg3 = '$baseUrl/trello/walkthrough3.png';
const tc_WalkThroughImg4 = '$baseUrl/trello/walkthrough4.png';

import 'package:flutter/material.dart';

const GMFloatingTextColor = Color(0xFFF06292);
const GMBlackColor = Color(0xFF000000);
const GMWhiteColor = Color(0xFFFFFFFF);
const GMGreyColor = Color(0xFF808080);
const GMAppDividerColor = Color(0xFFDADADA);
const GMRedColor = Color(0xFFD93025);
const GMGreenColor = Color(0xFF188038);
const GMYellowColor = Color(0xFFF9AB00);
const GMBlueColor = Color(0xFF1A73EB);

const String GMAppName = 'IMail';

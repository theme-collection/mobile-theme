package com.iqonic.shophop.models

import java.io.Serializable

class Shipping :Serializable{
     var address_1: String = ""
     var address_2: String = ""
     var city: String = ""
     var company: String = ""
     var country: String = ""
     var first_name: String = ""
     var last_name: String = ""
     var postcode: String = ""
     var state: String = ""
 }

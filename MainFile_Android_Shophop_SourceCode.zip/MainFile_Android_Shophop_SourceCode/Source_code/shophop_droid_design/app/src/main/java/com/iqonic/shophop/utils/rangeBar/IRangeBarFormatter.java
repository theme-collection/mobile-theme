package com.iqonic.shophop.utils.rangeBar;


public interface IRangeBarFormatter {

    String format(String value);

}

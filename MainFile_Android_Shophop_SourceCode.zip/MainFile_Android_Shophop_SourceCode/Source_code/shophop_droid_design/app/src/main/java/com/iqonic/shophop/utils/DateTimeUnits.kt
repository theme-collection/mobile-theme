package com.iqonic.shophop.utils

enum class DateTimeUnits {
    DAYS,
    HOURS,
    MINUTES,
    SECONDS,
    MILLISECONDS
}

package com.iqonic.shophop.models

class WishList{
    var average_rating: String? = null
    var colors: ArrayList<String>? = null
    var image: String? = null
    var name: String? = null
    var regular_price: String? = null
    var sale_price: String? = null
    var size: ArrayList<String>? = null
    var product_id: Int=0
    var item_id: Int=0
}

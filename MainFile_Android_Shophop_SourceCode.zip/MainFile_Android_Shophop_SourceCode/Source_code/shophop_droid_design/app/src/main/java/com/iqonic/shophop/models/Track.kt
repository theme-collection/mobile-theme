package com.iqonic.shophop.models

class Track{
   var status:TrackStatus?=null
    var trackStatus:String?=null
    var date:String?=null
    var isActive:Boolean?=false
    var isDone:Boolean?=true
}
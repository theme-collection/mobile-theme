package com.iqonic.datingapp.models

class Language {


     var launguge: String? = null
     var country: Int = 0

}
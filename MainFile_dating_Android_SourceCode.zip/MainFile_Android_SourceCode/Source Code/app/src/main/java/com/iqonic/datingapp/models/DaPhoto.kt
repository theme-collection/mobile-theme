package com.iqonic.datingapp.models


class DaPhoto {
    var img:Int?=0


}
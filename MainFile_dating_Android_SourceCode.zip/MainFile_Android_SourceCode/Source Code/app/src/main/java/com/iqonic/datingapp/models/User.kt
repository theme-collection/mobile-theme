package com.iqonic.datingapp.models

class User {
    var name:String?=null
    var distance:String?=null
    var age:String?=null
    var proffesion:String?=null
    var isOnline:Boolean=false
    var img:Int?=null

}
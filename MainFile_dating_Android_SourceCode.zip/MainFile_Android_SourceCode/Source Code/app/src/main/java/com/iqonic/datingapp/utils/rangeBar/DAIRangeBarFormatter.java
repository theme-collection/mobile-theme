package com.iqonic.datingapp.utils.rangeBar;


public interface DAIRangeBarFormatter {

    String format(String value);

}

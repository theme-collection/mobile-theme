package com.iqonic.datingapp.models


class DaNotification {
    var img :Int?=null
    var notification :String?=null
    var isSender :Boolean=false
    var time :String="Just Now"
    var day :String?=null


}
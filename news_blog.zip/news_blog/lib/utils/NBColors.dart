import 'package:flutter/material.dart';

const Color NBPrimaryColor = Color(0xFFFD5530);
const Color NBFacebookColor = Color(0xFF4265b0);

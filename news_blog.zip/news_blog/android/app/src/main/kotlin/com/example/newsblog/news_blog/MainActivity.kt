package com.example.newsblog.news_blog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

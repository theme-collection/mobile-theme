import 'package:flutter/material.dart';

const CSPrimaryColor = Color(0xFFFFFFFF);
const CSDarkBlueColor = Color.fromRGBO(3, 35, 150, 1);
const CSGreyColor = Color.fromRGBO(225, 225, 225, 1);

enum Sorting { Name, Modified }
enum AccessOption { edit, view }

const String CSAppName = "Cloudbox";

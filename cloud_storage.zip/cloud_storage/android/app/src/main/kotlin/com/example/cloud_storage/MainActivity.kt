package com.example.cloud_storage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

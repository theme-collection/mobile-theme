const DASender_id = 1;
const DAReceiver_id = 2;
const purChaseUrl = 'https://codecanyon.net/item/prokit-flutter-app-ui-design-templete-kit/25787190';

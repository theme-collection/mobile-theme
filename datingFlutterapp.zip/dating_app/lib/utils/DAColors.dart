import 'package:flutter/material.dart';

const primaryColor = Color(0xFFFF4E54);
const BHAppTextColorPrimary = Color(0xFF212121);

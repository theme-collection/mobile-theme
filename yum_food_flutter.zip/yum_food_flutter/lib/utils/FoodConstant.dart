const BaseUrl = 'https://assets.iqonic.design/old-themeforest-images/prokit';
const purchaseMoreUrl = "https://codecanyon.net/item/prokit-flutter-app-ui-design-templete-kit/25787190?s_rank=19";

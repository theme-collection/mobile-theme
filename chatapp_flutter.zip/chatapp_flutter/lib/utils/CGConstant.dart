// AppName
const CGAppName = 'ChatApp';
const CGAppPadding = 18.0;
const CGAppTextSize = 16.0;
const isDarkModeOnPref = "isDarkModeOnPref";

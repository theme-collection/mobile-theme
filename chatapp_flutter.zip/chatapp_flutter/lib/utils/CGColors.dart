import 'package:flutter/material.dart';

const primaryColor = Color(0xFFFFFFFF);
const secondaryColor = Color(0xFF075E54);
const textPrimaryColors = Color(0xFFfafafa);
const textSecondaryColors = Color(0xFF83AFAA);
const backgroundColor = Color(0xFFf6f7f7);
const iconPrimaryColor = Color(0XFFFFFFFF);
const buttonColor = Color(0XFF00CC3F);

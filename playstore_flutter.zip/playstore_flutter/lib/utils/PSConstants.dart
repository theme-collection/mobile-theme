const PSAppName = 'AppMarket';

const Review = 'By keeping all these questions in our mind today we have come up with a new topic called “A Guide on Paragraph Writing”. With this guide, we’ll '
    'try to answer all these questions about paragraph writing. Paragraphs act as the main role in a student’s life. While writing any topic in an'
    ' exam or competition needs paras to explain the concept in an understandable way for the readers';
const review1 = "I am a big fan of the many games on here and it dosen't Overheat my phone. The  games are amazing. Kids should really play these  types of games since there are even Puzzle game in it  ";

const isDarkModeOnPref = "isDarkModeOnPref";

const maxItemCount = 20;

const baseUrl = "https://assets.iqonic.design/old-themeforest-images/Mimik";

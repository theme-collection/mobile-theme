import 'package:flutter/material.dart';

const psColorGreen = Color(0xFF01875f);
const colorBlue = Color(0xFF2196F3);
const psColorRed = Color(0xFFd12121);
//const psColorGreenB = Color(0xFF01875f);

const GMFloatingTextColor = Color(0xFFF06292);
const GMBlackColor = Color(0xFF000000);
const GMWhiteColor = Color(0xFFFFFFFF);
const GMGreyColor = Color(0xFF808080);
const GMAppDividerColor = Color(0xFFDADADA);
const GMYellowColor = Color(0xFFF9AB00);
